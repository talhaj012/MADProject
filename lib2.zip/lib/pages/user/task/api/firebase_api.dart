import 'package:cloud_firestore/cloud_firestore.dart';
import '../Home Page/model/todo.dart';


class FirebaseApi {
  static Future<String> createTodo(Todo todo) async {
    final docTodo = FirebaseFirestore.instance.collection('tasks').doc();

    todo.id = docTodo.id;
    await docTodo.set(todo.toJson());

    return docTodo.id;
  }


}