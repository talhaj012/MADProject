import 'package:authentication/pages/login.dart';
import 'package:authentication/pages/signup.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class GetStarted extends StatelessWidget {
  const GetStarted({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.white,
        padding: EdgeInsets.all(25),
        child: ListView(
          children: [
            Container(
              height: 320,
              child: Lottie.asset('assets/get-started-btn.json'),
            ),
            Container(
              height: 300,
              child: Lottie.asset('assets/welcome.json'),
            ),
            Container(

              margin: EdgeInsets.symmetric(vertical: 15),
              // padding: EdgeInsets.symmetric(vertical: 10),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context,MaterialPageRoute(builder: (context)=>Login()));
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.all(18),
                  elevation: 10,
                  shadowColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),),
                ),
                child: Text('Login',
                  style: TextStyle(fontSize: 18.0),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 15),
              child: ElevatedButton(
                onPressed: (){
                  Navigator.push(context,MaterialPageRoute(builder: (context)=>Signup()));
                },
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.all(18),
                  elevation: 10,
                  shadowColor: Colors.black,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),),
                ),
                child: Text('Signup',
                  style: TextStyle(fontSize: 18.0),
                ),
              ),
            ),
            Center(
              child: Container(
                margin: EdgeInsets.only(top: 10),
                child: Text('version 3.0.2',
                    style: TextStyle(fontSize: 18.0,
                    color: Theme.of(context).primaryColor
                    )
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
