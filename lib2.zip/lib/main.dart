import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:authentication/pages/user/get_started.dart';
import 'package:authentication/pages/user/user_main.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:authentication/pages/login.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:lottie/lottie.dart';
import 'readData.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Future<FirebaseApp> _initialization = Firebase.initializeApp();

  final storage = new FlutterSecureStorage();

  Future<bool> checkingLoginStatus() async{
    String? value = await storage.read(key: 'uid');
    if(value == null){
      return false;
    }
    return true;
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
        future: _initialization,
        builder: (context, snapshot) {
          // checks for errors
          if (snapshot.hasError) {
            print("Somthing went wrong");
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          return MaterialApp(
            debugShowCheckedModeBanner: false,
            title: 'Flutter Demo',
            theme: ThemeData(
              primarySwatch: Colors.purple,
            ),
            // home: UserMain(),
            home: FutureBuilder(
                future: checkingLoginStatus(),
                builder: (BuildContext context, AsyncSnapshot<bool> snapshot){
                    if(snapshot.data == false){
                      return AnimatedSplashScreen(
                          // duration: 10000,
                          backgroundColor: Colors.white,
                          // splashTransition: SplashTransition.slideTransition,
                          splash: Lottie.asset('assets/splash_logo.json'),
                          nextScreen: GetStarted());;
                    }
                    if(snapshot.connectionState == ConnectionState.waiting){
                      return Container(
                        color: Colors.white,
                        child: Center(
                          child: CircularProgressIndicator(),
                        ),
                      );
                    }
                    return AnimatedSplashScreen(
                        // duration: 10000,
                        backgroundColor: Colors.white,
                        // splashTransition: SplashTransition.slideTransition,
                        splash: Lottie.asset('assets/splash_logo.json'),
                        nextScreen: UserMain());
                }),
            // home: ReadScreen(),
          );
        });
  }
}
